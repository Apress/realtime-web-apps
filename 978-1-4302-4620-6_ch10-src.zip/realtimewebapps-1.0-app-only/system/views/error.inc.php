
<section id="error">

    <h2>
        I&rsquo;m sorry, Dave.<br />
        I&rsquo;m afraid I can&rsquo;t do that.
    </h2>

    <p>
        Sorry, but something went wrong. Maybe the error message below 
        will help.
    </p>

    <p><code><?php echo $message; ?></code></p>

    <p>
        <a href="<?php echo $home_link; ?>">&larr; go back to the home page</a>
    </p>

</section>
