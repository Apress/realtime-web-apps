
<footer>
    <ul>
        <li class="copyright">
            &copy; 2013 Jason Lengstorf &amp; Phil Leggetter
        </li><!--/.copyright-->
        <li>
            Part of <em>Realtime Web Apps: With HTML5 WebSocket, PHP,
            and jQuery</em>.
        </li>
        <li>
            <a href="http://amzn.to/S2HRiS">Get the Book</a> |
            <a href="http://cptr.me/UkMSmn">Source Code (on GitHub)</a>
        </li>
    </ul>
</footer>

</body>

</html>
